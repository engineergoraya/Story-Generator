import { useState } from "react";
import StoryGenerator from "@/components/story-generator";
import StoryDisplay from "@/components/story-display";
import { Story } from "@shared/schema";

export default function Home() {
  const [currentStory, setCurrentStory] = useState<Story | null>(null);

  const handleStoryGenerated = (story: Story) => {
    setCurrentStory(story);
  };

  const handleCreateNewStory = () => {
    setCurrentStory(null);
  };

  return (
    <div className="bg-gradient-to-br from-purple-100 via-blue-50 to-pink-100 min-h-screen">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b-2 border-magic-purple/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-magic-purple to-magic-blue rounded-xl flex items-center justify-center text-white text-xl animate-pulse-slow">
                  📚
                </div>
                <div className="absolute -top-1 -right-1 text-magic-yellow text-sm animate-sparkle">
                  ✨
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <h1 className="text-3xl font-fredoka text-magic-purple">StorySpark</h1>
                <div className="text-2xl animate-bounce-slow">
                  🏰
                </div>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-sm text-gray-600 font-medium">✨ Magical Stories Await!</div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {!currentStory ? (
          <StoryGenerator onStoryGenerated={handleStoryGenerated} />
        ) : (
          <StoryDisplay story={currentStory} onCreateNewStory={handleCreateNewStory} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white/80 backdrop-blur-sm border-t-2 border-magic-purple/20 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              <div className="relative mr-2">
                <div className="w-8 h-8 bg-gradient-to-br from-magic-purple to-magic-blue rounded-lg flex items-center justify-center text-white text-sm">
                  📚
                </div>
                <div className="absolute -top-0.5 -right-0.5 text-magic-yellow text-xs animate-sparkle">
                  ✨
                </div>
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-xl font-fredoka text-magic-purple">StorySpark</span>
                <div className="text-lg animate-bounce-slow">
                  🏰
                </div>
              </div>
            </div>
            <p className="text-gray-600 mb-4">Creating magical stories for curious minds ✨</p>
            <div className="text-sm text-gray-500">
              Safe & Kid-Friendly • Educational Fun
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
