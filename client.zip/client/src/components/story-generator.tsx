import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Story, StoryGenerationRequest } from "@shared/schema";
import { cn } from "@/lib/utils";

interface StoryGeneratorProps {
  onStoryGenerated: (story: Story) => void;
}

type FormType = 'home' | 'custom' | 'surprise';

export default function StoryGenerator({ onStoryGenerated }: StoryGeneratorProps) {
  const [formType, setFormType] = useState<FormType>('home');
  const [storyIdea, setStoryIdea] = useState('');
  const [age, setAge] = useState('7-9');
  const [favoriteCreature, setFavoriteCreature] = useState('Dragon');
  const [setting, setSetting] = useState('forest');
  const [mood, setMood] = useState('adventurous');
  const { toast } = useToast();

  const generateStoryMutation = useMutation({
    mutationFn: async (data: StoryGenerationRequest): Promise<Story> => {
      const response = await apiRequest('POST', '/api/stories/generate', data);
      return response.json();
    },
    onSuccess: (story) => {
      onStoryGenerated(story);
    },
    onError: (error: any) => {
      if (error.message.includes('inappropriate_content') || error.message.includes('keep the magic safe')) {
        toast({
          title: "Let's Keep the Magic Safe and Joyful!",
          description: "That idea might be a little too scary for our magical story world. Can you give me a fun, happy idea to start with instead?",
          variant: "destructive",
        });
      } else if (error.message.includes('usage limit') || error.message.includes('insufficient_quota')) {
        toast({
          title: "API Usage Limit Reached",
          description: "Your OpenAI API key has reached its usage limit. Please check your OpenAI billing and add credits to continue creating stories!",
          variant: "destructive",
        });
      } else if (error.message.includes('invalid') || error.message.includes('401')) {
        toast({
          title: "API Key Issue",
          description: "Your OpenAI API key seems to be invalid. Please check your API key in the secrets section.",
          variant: "destructive",
        });
      } else if (error.message.includes('busy') || error.message.includes('429')) {
        toast({
          title: "Service Temporarily Busy",
          description: "The OpenAI service is busy right now. Please wait a few moments and try again!",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Oops! Something went wrong",
          description: error.message || "The story fairies are taking a break! Please try again in a moment.",
          variant: "destructive",
        });
      }
    },
  });

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storyIdea.trim()) {
      toast({
        title: "Story idea needed!",
        description: "Please tell us your story idea! 🌟",
        variant: "destructive",
      });
      return;
    }
    
    generateStoryMutation.mutate({
      type: 'custom',
      age,
      storyIdea,
      favoriteCreature,
      setting,
    });
  };

  const handleSurpriseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    generateStoryMutation.mutate({
      type: 'surprise',
      age,
      mood,
    });
  };

  const handleGoBack = () => {
    setFormType('home');
  };

  if (generateStoryMutation.isPending) {
    return (
      <div className="max-w-3xl mx-auto text-center">
        <Card className="border-4 border-magic-purple/20">
          <CardContent className="p-12">
            <div className="mb-8">
              <div className="w-24 h-24 bg-gradient-to-br from-magic-purple to-magic-blue rounded-full flex items-center justify-center text-white text-4xl mx-auto animate-pulse-slow">
                <i className="fas fa-magic"></i>
              </div>
            </div>
            <h3 className="text-3xl font-fredoka text-magic-purple mb-4">Creating Your Magical Story...</h3>
            <p className="text-lg text-gray-600 mb-8">The story fairies are working their magic! This will just take a moment. ✨</p>
            
            <div className="w-full bg-gray-200 rounded-full h-4 mb-6">
              <div className="bg-gradient-to-r from-magic-purple to-magic-blue h-4 rounded-full animate-pulse w-3/5"></div>
            </div>
            
            <div className="flex justify-center space-x-4 text-2xl">
              <span className="animate-bounce text-magic-yellow" style={{ animationDelay: '0s' }}>⭐</span>
              <span className="animate-bounce text-magic-pink" style={{ animationDelay: '0.2s' }}>✨</span>
              <span className="animate-bounce text-magic-blue" style={{ animationDelay: '0.4s' }}>🌟</span>
              <span className="animate-bounce text-magic-green" style={{ animationDelay: '0.6s' }}>💫</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (formType === 'home') {
    return (
      <>
        {/* Hero Section */}
        <section className="text-center mb-12">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8 relative">
              <img 
                src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=400" 
                alt="Magical children's books with sparkles and fantasy elements" 
                className="rounded-3xl shadow-2xl w-full h-64 md:h-80 object-cover mx-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-magic-purple/20 to-transparent rounded-3xl"></div>
              <div className="absolute top-4 right-4 text-magic-yellow text-2xl animate-sparkle">
                <i className="fas fa-star"></i>
              </div>
              <div className="absolute bottom-4 left-4 text-magic-pink text-xl animate-bounce-slow">
                <i className="fas fa-magic"></i>
              </div>
            </div>
            
            <h2 className="text-4xl md:text-6xl font-fredoka text-magic-purple mb-6 leading-tight">
              Create Magical Stories Together!
            </h2>
            <p className="text-lg md:text-xl text-gray-700 mb-8 max-w-2xl mx-auto leading-relaxed">
              Tell me what you'd like your story to be about, and I'll create a wonderful fantasy adventure just for you! ✨
            </p>
          </div>
        </section>

        {/* Story Options */}
        <section className="mb-12">
          <div className="max-w-4xl mx-auto">
            <h3 className="text-2xl md:text-3xl font-fredoka text-center text-magic-purple mb-8">
              How would you like to start your adventure?
            </h3>
            
            <div className="grid md:grid-cols-2 gap-8">
              {/* Custom Story Option */}
              <Card 
                className="border-4 border-magic-blue/20 hover:border-magic-blue/40 transition-all duration-300 transform hover:scale-105 cursor-pointer"
                onClick={() => setFormType('custom')}
                data-testid="option-custom"
              >
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-magic-blue to-magic-purple rounded-full flex items-center justify-center text-white text-3xl mx-auto mb-6">
                    <i className="fas fa-pen-fancy"></i>
                  </div>
                  <h4 className="text-2xl font-fredoka text-magic-blue mb-4">Tell Me Your Idea!</h4>
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    Share your favorite character, magical place, or adventure idea and I'll create a special story just for you!
                  </p>
                  <Button 
                    className="bg-gradient-to-r from-magic-blue to-magic-purple text-white hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                    data-testid="button-start-creating"
                  >
                    Start Creating! <i className="fas fa-arrow-right ml-2"></i>
                  </Button>
                </CardContent>
              </Card>

              {/* Surprise Me Option */}
              <Card 
                className="border-4 border-magic-pink/20 hover:border-magic-pink/40 transition-all duration-300 transform hover:scale-105 cursor-pointer"
                onClick={() => setFormType('surprise')}
                data-testid="option-surprise"
              >
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-magic-pink to-magic-orange rounded-full flex items-center justify-center text-white text-3xl mx-auto mb-6 animate-pulse-slow">
                    <i className="fas fa-surprise"></i>
                  </div>
                  <h4 className="text-2xl font-fredoka text-magic-pink mb-4">Surprise Me!</h4>
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    Let me create a completely magical surprise story for you! You never know what amazing adventure awaits!
                  </p>
                  <Button 
                    className="bg-gradient-to-r from-magic-pink to-magic-orange text-white hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                    data-testid="button-surprise-me"
                  >
                    Surprise Me! <i className="fas fa-magic ml-2"></i>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </>
    );
  }

  if (formType === 'custom') {
    return (
      <div className="max-w-3xl mx-auto">
        <Card className="border-4 border-magic-blue/20">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h3 className="text-3xl font-fredoka text-magic-blue mb-4">Let's Create Your Story!</h3>
              <p className="text-gray-600">Tell me a little bit about the story you'd like to hear...</p>
            </div>

            <form onSubmit={handleCustomSubmit} className="space-y-6">
              {/* Story Idea Input */}
              <div>
                <label className="block text-lg font-semibold text-magic-purple mb-3">
                  <i className="fas fa-lightbulb text-magic-yellow mr-2"></i>
                  What's your story idea?
                </label>
                <Textarea 
                  placeholder="Tell me about a character, place, or adventure you'd like in your story! For example: 'A brave dragon who loves to bake cookies' or 'A magical library where books come to life'"
                  className="border-2 border-gray-200 focus:border-magic-blue focus:ring-4 focus:ring-magic-blue/20 resize-none h-32 text-lg"
                  value={storyIdea}
                  onChange={(e) => setStoryIdea(e.target.value)}
                  data-testid="input-story-idea"
                />
              </div>

              {/* Age Selection */}
              <div>
                <label className="block text-lg font-semibold text-magic-purple mb-3">
                  <i className="fas fa-birthday-cake text-magic-pink mr-2"></i>
                  How old are you?
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {['4-6', '7-9', '10-12', '13+'].map((ageOption) => (
                    <Button
                      key={ageOption}
                      type="button"
                      variant="outline"
                      className={cn(
                        "p-3 border-2 rounded-xl transition-all duration-200 text-center font-semibold",
                        age === ageOption 
                          ? "border-magic-blue bg-magic-blue/10" 
                          : "border-gray-200 hover:border-magic-blue hover:bg-magic-blue/10"
                      )}
                      onClick={() => setAge(ageOption)}
                      data-testid={`age-${ageOption}`}
                    >
                      {ageOption} years
                    </Button>
                  ))}
                </div>
              </div>

              {/* Favorite Creature */}
              <div>
                <label className="block text-lg font-semibold text-magic-purple mb-3">
                  <i className="fas fa-paw text-magic-green mr-2"></i>
                  What's your favorite magical creature?
                </label>
                <Select value={favoriteCreature} onValueChange={setFavoriteCreature}>
                  <SelectTrigger className="border-2 border-gray-200 focus:border-magic-blue focus:ring-4 focus:ring-magic-blue/20 text-lg" data-testid="select-creature">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Dragon">Dragon</SelectItem>
                    <SelectItem value="Unicorn">Unicorn</SelectItem>
                    <SelectItem value="Phoenix">Phoenix</SelectItem>
                    <SelectItem value="Griffin">Griffin</SelectItem>
                    <SelectItem value="Fairy">Fairy</SelectItem>
                    <SelectItem value="Wizard">Wizard</SelectItem>
                    <SelectItem value="Talking Animal">Talking Animal</SelectItem>
                    <SelectItem value="Magical Robot">Magical Robot</SelectItem>
                    <SelectItem value="Surprise me!">Surprise me!</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Setting Preference */}
              <div>
                <label className="block text-lg font-semibold text-magic-purple mb-3">
                  <i className="fas fa-map text-magic-orange mr-2"></i>
                  Where should your adventure take place?
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    { value: 'forest', label: '🌲 Magical Forest' },
                    { value: 'castle', label: '🏰 Enchanted Castle' },
                    { value: 'underwater', label: '🌊 Underwater Kingdom' },
                    { value: 'clouds', label: '☁️ Cloud City' },
                    { value: 'space', label: '🚀 Magical Space' },
                    { value: 'surprise', label: '✨ Surprise me!' }
                  ].map((settingOption) => (
                    <Button
                      key={settingOption.value}
                      type="button"
                      variant="outline"
                      className={cn(
                        "p-3 border-2 rounded-xl transition-all duration-200 text-center font-semibold",
                        setting === settingOption.value 
                          ? "border-magic-green bg-magic-green/10" 
                          : "border-gray-200 hover:border-magic-green hover:bg-magic-green/10"
                      )}
                      onClick={() => setSetting(settingOption.value)}
                      data-testid={`setting-${settingOption.value}`}
                    >
                      {settingOption.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-6">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={handleGoBack}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700"
                  data-testid="button-go-back"
                >
                  <i className="fas fa-arrow-left mr-2"></i>
                  Go Back
                </Button>
                <Button 
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-magic-blue to-magic-purple text-white hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                  disabled={generateStoryMutation.isPending}
                  data-testid="button-create-story"
                >
                  Create My Story! <i className="fas fa-magic ml-2"></i>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (formType === 'surprise') {
    return (
      <div className="max-w-3xl mx-auto">
        <Card className="border-4 border-magic-pink/20">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h3 className="text-3xl font-fredoka text-magic-pink mb-4">Surprise Story Time!</h3>
              <p className="text-gray-600">Just a few quick questions to make your surprise extra special...</p>
            </div>

            <form onSubmit={handleSurpriseSubmit} className="space-y-6">
              {/* Age Selection */}
              <div>
                <label className="block text-lg font-semibold text-magic-purple mb-3">
                  <i className="fas fa-birthday-cake text-magic-pink mr-2"></i>
                  How old are you?
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {['4-6', '7-9', '10-12', '13+'].map((ageOption) => (
                    <Button
                      key={ageOption}
                      type="button"
                      variant="outline"
                      className={cn(
                        "p-3 border-2 rounded-xl transition-all duration-200 text-center font-semibold",
                        age === ageOption 
                          ? "border-magic-pink bg-magic-pink/10" 
                          : "border-gray-200 hover:border-magic-pink hover:bg-magic-pink/10"
                      )}
                      onClick={() => setAge(ageOption)}
                      data-testid={`surprise-age-${ageOption}`}
                    >
                      {ageOption} years
                    </Button>
                  ))}
                </div>
              </div>

              {/* Mood Selection */}
              <div>
                <label className="block text-lg font-semibold text-magic-purple mb-3">
                  <i className="fas fa-heart text-magic-pink mr-2"></i>
                  What kind of story mood sounds good?
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    { value: 'adventurous', label: '🗡️ Adventurous' },
                    { value: 'funny', label: '😄 Funny' },
                    { value: 'heartwarming', label: '💝 Heartwarming' },
                    { value: 'mysterious', label: '🔍 Mysterious' },
                    { value: 'magical', label: '✨ Super Magical' },
                    { value: 'total-surprise', label: '🎲 Total Surprise!' }
                  ].map((moodOption) => (
                    <Button
                      key={moodOption.value}
                      type="button"
                      variant="outline"
                      className={cn(
                        "p-3 border-2 rounded-xl transition-all duration-200 text-center font-semibold",
                        mood === moodOption.value 
                          ? "border-magic-yellow bg-magic-yellow/10" 
                          : "border-gray-200 hover:border-magic-yellow hover:bg-magic-yellow/10"
                      )}
                      onClick={() => setMood(moodOption.value)}
                      data-testid={`mood-${moodOption.value}`}
                    >
                      {moodOption.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-6">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={handleGoBack}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700"
                  data-testid="button-go-back-surprise"
                >
                  <i className="fas fa-arrow-left mr-2"></i>
                  Go Back
                </Button>
                <Button 
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-magic-pink to-magic-orange text-white hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                  disabled={generateStoryMutation.isPending}
                  data-testid="button-create-surprise-story"
                >
                  Surprise Me! <i className="fas fa-surprise ml-2"></i>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}
