import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Story } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface StoryDisplayProps {
  story: Story;
  onCreateNewStory: () => void;
}

export default function StoryDisplay({ story, onCreateNewStory }: StoryDisplayProps) {
  const [isReading, setIsReading] = useState(false);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { toast } = useToast();

  const copyStory = async () => {
    const fullStory = `${story.title}\n\n${story.content}\n\nMoral of the Story: ${story.moral}`;
    
    try {
      await navigator.clipboard.writeText(fullStory);
      toast({
        title: "Story copied!",
        description: "Story copied to clipboard! 📋✨",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Unable to copy story. Please try again! 😊",
        variant: "destructive",
      });
    }
  };

  const downloadStory = () => {
    const fullStory = `${story.title}\n\n${story.content}\n\nMoral of the Story: ${story.moral}`;
    
    const blob = new Blob([fullStory], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${story.title.replace(/[^a-z0-9]/gi, '_')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Story downloaded!",
      description: "Story downloaded! 📥✨",
    });
  };

  const readStory = async () => {
    // If audio is currently playing, stop it
    if (isReading && audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsReading(false);
      return;
    }

    try {
      setIsGeneratingAudio(true);
      
      const fullStory = `${story.title}. ${story.content}. Moral of the Story: ${story.moral}`;
      
      // Generate audio using ElevenLabs
      const response = await apiRequest('POST', '/api/tts/generate', { text: fullStory });
      
      if (!response.ok) {
        throw new Error('Failed to generate audio');
      }

      // Create audio blob and URL
      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      
      // Create and configure audio element
      const audio = new Audio(audioUrl);
      audioRef.current = audio;
      
      audio.onplay = () => {
        setIsReading(true);
        setIsGeneratingAudio(false);
      };
      
      audio.onended = () => {
        setIsReading(false);
        URL.revokeObjectURL(audioUrl);
      };
      
      audio.onerror = () => {
        setIsReading(false);
        setIsGeneratingAudio(false);
        URL.revokeObjectURL(audioUrl);
        toast({
          title: "Audio playback failed",
          description: "There was an issue playing the audio. Please try again! 😊",
          variant: "destructive",
        });
      };

      // Start playing
      await audio.play();
      
      toast({
        title: "Professional narrator reading your story!",
        description: "Enjoy the beautiful narration! 🎭✨",
      });
      
    } catch (error) {
      console.error('TTS error:', error);
      setIsGeneratingAudio(false);
      setIsReading(false);
      
      toast({
        title: "Audio generation failed",
        description: "Unable to generate audio. Please try again! 😊",
        variant: "destructive",
      });
    }
  };

  // Split content into paragraphs
  const paragraphs = story.content.split('\n').filter(p => p.trim());

  return (
    <div className="max-w-4xl mx-auto">
      {/* Story Header */}
      <div className="bg-gradient-to-r from-magic-purple to-magic-blue text-white rounded-t-3xl p-8 text-center">
        <div className="flex items-center justify-center mb-4">
          <i className="fas fa-book-open text-3xl mr-3"></i>
          <h3 className="text-3xl font-fredoka">Your Magical Story</h3>
          <i className="fas fa-sparkles text-3xl ml-3"></i>
        </div>
        <div className="text-lg opacity-90">Created just for you! ✨</div>
      </div>

      {/* Story Content */}
      <Card className="rounded-t-none border-t-0 border-4 border-magic-purple/20">
        <CardContent className="p-8">
          {/* Story Title */}
          <div className="text-center mb-8">
            <h4 className="text-4xl font-fredoka text-magic-purple mb-4" data-testid="story-title">
              {story.title}
            </h4>
            <div className="w-24 h-1 bg-gradient-to-r from-magic-pink to-magic-yellow mx-auto rounded-full"></div>
          </div>

          {/* Story Text */}
          <div className="prose prose-lg max-w-none text-gray-800 leading-relaxed space-y-6" data-testid="story-content">
            {paragraphs.map((paragraph, index) => (
              <p key={index} className="text-xl leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>

          {/* Moral Section */}
          <div className="mt-8 p-6 bg-gradient-to-r from-magic-yellow/20 to-magic-orange/20 rounded-2xl border-2 border-magic-yellow/30">
            <h5 className="text-2xl font-fredoka text-magic-orange mb-3 flex items-center">
              <i className="fas fa-heart mr-2"></i>
              Moral of the Story
            </h5>
            <p className="text-lg text-gray-700 font-medium" data-testid="story-moral">
              {story.moral}
            </p>
          </div>

          {/* Story Actions */}
          <div className="mt-8 flex flex-wrap gap-4 justify-center">
            <Button 
              onClick={copyStory}
              className="bg-magic-blue text-white hover:bg-magic-blue/90 transition-all duration-300"
              data-testid="button-copy"
            >
              <i className="fas fa-copy mr-2"></i>
              Copy Story
            </Button>
            <Button 
              onClick={downloadStory}
              className="bg-magic-green text-white hover:bg-magic-green/90 transition-all duration-300"
              data-testid="button-download"
            >
              <i className="fas fa-download mr-2"></i>
              Download TXT
            </Button>
            <Button 
              onClick={readStory}
              disabled={isGeneratingAudio}
              className="bg-magic-purple text-white hover:bg-magic-purple/90 transition-all duration-300 disabled:opacity-50"
              data-testid="button-read"
            >
              <i className={`fas ${isGeneratingAudio ? 'fa-spinner fa-spin' : isReading ? 'fa-stop' : 'fa-microphone'} mr-2`}></i>
              {isGeneratingAudio ? 'Generating Audio...' : isReading ? 'Stop Narration' : 'Professional Narrator'}
            </Button>
            <Button 
              onClick={onCreateNewStory}
              className="bg-magic-pink text-white hover:bg-magic-pink/90 transition-all duration-300"
              data-testid="button-new-story"
            >
              <i className="fas fa-plus mr-2"></i>
              New Story
            </Button>
          </div>

          {/* Word Count */}
          <div className="mt-6 text-center text-sm text-gray-500">
            <i className="fas fa-file-alt mr-1"></i>
            Word count: <span data-testid="word-count">{story.wordCount}</span> words
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
