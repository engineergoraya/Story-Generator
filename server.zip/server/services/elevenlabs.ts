import fetch, { Response } from 'node-fetch';

const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY;
const ELEVENLABS_API_URL = 'https://api.elevenlabs.io/v1';

// Rachel voice ID - a professional, warm female narrator perfect for children's stories
const RACHEL_VOICE_ID = '21m00Tcm4TlvDq8ikWAM';

interface TTSRequest {
  text: string;
  voice_settings?: {
    stability: number;
    similarity_boost: number;
    style?: number;
    use_speaker_boost?: boolean;
  };
}

export async function generateSpeech(text: string): Promise<Buffer> {
  if (!ELEVENLABS_API_KEY) {
    throw new Error('ElevenLabs API key not configured');
  }

  const payload: TTSRequest = {
    text,
    voice_settings: {
      stability: 0.5,        // Balanced stability for natural flow
      similarity_boost: 0.8, // High similarity for consistent voice
      style: 0.2,            // Slight style variation for storytelling
      use_speaker_boost: true // Enhanced clarity
    }
  };

  try {
    const response = await fetch(
      `${ELEVENLABS_API_URL}/text-to-speech/${RACHEL_VOICE_ID}`,
      {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': ELEVENLABS_API_KEY,
        },
        body: JSON.stringify(payload),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error('ElevenLabs API error:', response.status, errorText);
      throw new Error(`ElevenLabs API error: ${response.status}`);
    }

    const audioBuffer = await response.buffer();
    return audioBuffer;
  } catch (error) {
    console.error('Speech generation error:', error);
    throw new Error('Failed to generate speech. Please try again.');
  }
}

export async function getAvailableVoices() {
  if (!ELEVENLABS_API_KEY) {
    throw new Error('ElevenLabs API key not configured');
  }

  try {
    const response = await fetch(`${ELEVENLABS_API_URL}/voices`, {
      headers: {
        'xi-api-key': ELEVENLABS_API_KEY,
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch voices: ${response.status}`);
    }

    const voices = await response.json();
    return voices;
  } catch (error) {
    console.error('Error fetching voices:', error);
    throw error;
  }
}