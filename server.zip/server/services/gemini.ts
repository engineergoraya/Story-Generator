import * as fs from "fs";
import { GoogleGenAI } from "@google/genai";

// Initialize Gemini AI with API key from environment
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

interface StoryParams {
  type: 'custom' | 'surprise';
  age: string;
  storyIdea?: string;
  favoriteCreature?: string;
  setting?: string;
  mood?: string;
}

interface GeneratedStory {
  title: string;
  content: string;
  moral: string;
  wordCount: number;
}

export async function generateStory(params: StoryParams): Promise<GeneratedStory> {
  // Content moderation check
  if (params.storyIdea) {
    const isAppropriate = await moderateContent(params.storyIdea);
    if (!isAppropriate) {
      throw new Error("Let's keep the magic safe and joyful! Can you give me a fun idea to start with?");
    }
  }

  const prompt = buildStoryPrompt(params);

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: "You are a magical storyteller who creates wonderful, age-appropriate fantasy stories for children. Your stories should be uplifting, educational, and filled with positive values. Always include a clear moral lesson. Keep stories under 1000 words. Respond with JSON in this format: { \"title\": \"Story Title\", \"content\": \"Story content in 4-6 paragraphs\", \"moral\": \"The moral lesson\" }",
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            title: { type: "string" },
            content: { type: "string" },
            moral: { type: "string" }
          },
          required: ["title", "content", "moral"]
        }
      },
      contents: prompt
    });

    const rawJson = response.text;
    console.log(`Gemini response: ${rawJson}`);

    if (!rawJson) {
      throw new Error("Failed to generate a complete story");
    }

    const result: GeneratedStory = JSON.parse(rawJson);
    
    if (!result.title || !result.content || !result.moral) {
      throw new Error("Failed to generate a complete story");
    }

    const wordCount = countWords(result.content);
    
    if (wordCount > 1000) {
      // Try to generate a shorter version
      return await generateShorterStory(params);
    }

    return {
      title: result.title,
      content: result.content,
      moral: result.moral,
      wordCount
    };
  } catch (error: any) {
    console.error('Gemini API error:', error);
    
    // Check for specific Gemini error types
    if (error?.status === 429) {
      throw new Error("The Gemini service is busy right now. Please wait a few moments and try again!");
    } else if (error?.status === 401 || error?.message?.includes('API key')) {
      throw new Error("Your Gemini API key seems to be invalid. Please check your API key in the secrets section.");
    } else if (error?.status === 403) {
      throw new Error("It looks like your Gemini API key has reached its usage limit. Please check your Google Cloud billing and add credits to continue creating stories!");
    }
    
    throw new Error("The story fairies are taking a break! Please try again in a moment.");
  }
}

async function generateShorterStory(params: StoryParams): Promise<GeneratedStory> {
  const prompt = buildStoryPrompt(params) + " Keep the story short and concise, under 800 words.";

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    config: {
      systemInstruction: "You are a magical storyteller who creates wonderful, short fantasy stories for children. Keep stories under 800 words with 4-5 paragraphs. Always include a clear moral lesson. Respond with JSON in this format: { \"title\": \"Story Title\", \"content\": \"Story content\", \"moral\": \"The moral lesson\" }",
      responseMimeType: "application/json",
      responseSchema: {
        type: "object",
        properties: {
          title: { type: "string" },
          content: { type: "string" },
          moral: { type: "string" }
        },
        required: ["title", "content", "moral"]
      }
    },
    contents: prompt
  });

  const result = JSON.parse(response.text || "{}");
  const wordCount = countWords(result.content);

  return {
    title: result.title,
    content: result.content,
    moral: result.moral,
    wordCount
  };
}

async function moderateContent(content: string): Promise<boolean> {
  try {
    // Use Gemini for content moderation
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Please analyze this content for appropriateness for children aged 4-13. Respond with only "SAFE" if it's appropriate for kids, or "UNSAFE" if it contains violence, scary content, inappropriate themes, or anything unsuitable for children: "${content}"`
    });

    const result = response.text?.trim().toUpperCase();
    
    if (result === "SAFE") {
      return true;
    }

    // Additional custom checks for kid-inappropriate content
    const inappropriateWords = [
      'scary', 'frightening', 'terrifying', 'horror', 'violent', 'death', 
      'kill', 'murder', 'blood', 'war', 'fight', 'dark', 'evil', 'demon',
      'monster', 'nightmare', 'afraid', 'fear'
    ];

    const lowerContent = content.toLowerCase();
    return !inappropriateWords.some(word => lowerContent.includes(word));
  } catch (error) {
    console.error('Content moderation error:', error);
    // If moderation fails, be conservative and reject
    return false;
  }
}

function buildStoryPrompt(params: StoryParams): string {
  const ageGroupText = getAgeGroupText(params.age);
  
  if (params.type === 'custom') {
    return `Create a magical fantasy story for ${ageGroupText} about: ${params.storyIdea}. 
            ${params.favoriteCreature ? `Include a ${params.favoriteCreature} character.` : ''}
            ${params.setting ? `Set the story in: ${params.setting}.` : ''}
            Make it educational, uplifting, and age-appropriate with a clear moral lesson.
            The story should be 4-6 paragraphs long and under 1000 words.`;
  } else {
    return `Create a surprise magical fantasy story for ${ageGroupText}.
            ${params.mood ? `The story should have a ${params.mood} mood.` : ''}
            Include magical creatures, an adventure, and make it educational and uplifting.
            The story should be 4-6 paragraphs long and under 1000 words with a clear moral lesson.`;
  }
}

function getAgeGroupText(age: string): string {
  switch (age) {
    case '4-6': return 'preschoolers (ages 4-6)';
    case '7-9': return 'early elementary children (ages 7-9)';
    case '10-12': return 'middle elementary children (ages 10-12)';
    case '13+': return 'teenagers';
    default: return 'children';
  }
}

function countWords(text: string): number {
  return text.split(/\s+/).filter(word => word.length > 0).length;
}