import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "your-api-key-here"
});

interface StoryParams {
  type: 'custom' | 'surprise';
  age: string;
  storyIdea?: string;
  favoriteCreature?: string;
  setting?: string;
  mood?: string;
}

interface GeneratedStory {
  title: string;
  content: string;
  moral: string;
  wordCount: number;
}

export async function generateStory(params: StoryParams): Promise<GeneratedStory> {
  // Content moderation check
  if (params.storyIdea) {
    const isAppropriate = await moderateContent(params.storyIdea);
    if (!isAppropriate) {
      throw new Error("Let's keep the magic safe and joyful! Can you give me a fun idea to start with?");
    }
  }

  const prompt = buildStoryPrompt(params);

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a magical storyteller who creates wonderful, age-appropriate fantasy stories for children. Your stories should be uplifting, educational, and filled with positive values. Always include a clear moral lesson. Keep stories under 1000 words. Respond with JSON in this format: { \"title\": \"Story Title\", \"content\": \"Story content in 4-6 paragraphs\", \"moral\": \"The moral lesson\" }"
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1500,
      temperature: 0.8,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    if (!result.title || !result.content || !result.moral) {
      throw new Error("Failed to generate a complete story");
    }

    const wordCount = countWords(result.content);
    
    if (wordCount > 1000) {
      // Try to generate a shorter version
      return await generateShorterStory(params);
    }

    return {
      title: result.title,
      content: result.content,
      moral: result.moral,
      wordCount
    };
  } catch (error: any) {
    console.error('OpenAI API error:', error);
    
    // Check for specific OpenAI error types
    if (error?.status === 429 && error?.code === 'insufficient_quota') {
      throw new Error("It looks like your OpenAI API key has reached its usage limit. Please check your OpenAI billing and add credits to continue creating stories!");
    } else if (error?.status === 401) {
      throw new Error("Your OpenAI API key seems to be invalid. Please check your API key in the secrets section.");
    } else if (error?.status === 429) {
      throw new Error("The OpenAI service is busy right now. Please wait a few moments and try again!");
    }
    
    throw new Error("The story fairies are taking a break! Please try again in a moment.");
  }
}

async function generateShorterStory(params: StoryParams): Promise<GeneratedStory> {
  const prompt = buildStoryPrompt(params) + " Keep the story short and concise, under 800 words.";

  const response = await openai.chat.completions.create({
    model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    messages: [
      {
        role: "system",
        content: "You are a magical storyteller who creates wonderful, short fantasy stories for children. Keep stories under 800 words with 4-5 paragraphs. Always include a clear moral lesson. Respond with JSON in this format: { \"title\": \"Story Title\", \"content\": \"Story content\", \"moral\": \"The moral lesson\" }"
      },
      {
        role: "user",
        content: prompt
      }
    ],
    response_format: { type: "json_object" },
    max_tokens: 1200,
    temperature: 0.8,
  });

  const result = JSON.parse(response.choices[0].message.content || "{}");
  const wordCount = countWords(result.content);

  return {
    title: result.title,
    content: result.content,
    moral: result.moral,
    wordCount
  };
}

async function moderateContent(content: string): Promise<boolean> {
  try {
    const moderation = await openai.moderations.create({
      input: content
    });

    const result = moderation.results[0];
    
    // Check for any flagged categories
    if (result.flagged) {
      return false;
    }

    // Additional custom checks for kid-inappropriate content
    const inappropriateWords = [
      'scary', 'frightening', 'terrifying', 'horror', 'violent', 'death', 
      'kill', 'murder', 'blood', 'war', 'fight', 'dark', 'evil', 'demon',
      'monster', 'nightmare', 'afraid', 'fear'
    ];

    const lowerContent = content.toLowerCase();
    return !inappropriateWords.some(word => lowerContent.includes(word));
  } catch (error) {
    console.error('Content moderation error:', error);
    // If moderation fails, be conservative and reject
    return false;
  }
}

function buildStoryPrompt(params: StoryParams): string {
  const ageGroupText = getAgeGroupText(params.age);
  
  if (params.type === 'custom') {
    return `Create a magical fantasy story for ${ageGroupText} about: ${params.storyIdea}. 
            ${params.favoriteCreature ? `Include a ${params.favoriteCreature} character.` : ''}
            ${params.setting ? `Set the story in: ${params.setting}.` : ''}
            Make it educational, uplifting, and age-appropriate with a clear moral lesson.
            The story should be 4-6 paragraphs long and under 1000 words.`;
  } else {
    return `Create a surprise magical fantasy story for ${ageGroupText}.
            ${params.mood ? `The story should have a ${params.mood} mood.` : ''}
            Include magical creatures, an adventure, and make it educational and uplifting.
            The story should be 4-6 paragraphs long and under 1000 words with a clear moral lesson.`;
  }
}

function getAgeGroupText(age: string): string {
  switch (age) {
    case '4-6': return 'preschoolers (ages 4-6)';
    case '7-9': return 'early elementary children (ages 7-9)';
    case '10-12': return 'middle elementary children (ages 10-12)';
    case '13+': return 'teenagers';
    default: return 'children';
  }
}

function countWords(text: string): number {
  return text.split(/\s+/).filter(word => word.length > 0).length;
}
