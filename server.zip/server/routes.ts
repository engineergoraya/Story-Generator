import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { storyGenerationSchema } from "@shared/schema";
import { generateStory } from "./services/gemini";
import { generateSpeech } from "./services/elevenlabs";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Generate story endpoint
  app.post("/api/stories/generate", async (req, res) => {
    try {
      const validatedData = storyGenerationSchema.parse(req.body);
      
      const generatedStory = await generateStory(validatedData);
      
      // Save the story to storage
      const savedStory = await storage.createStory({
        title: generatedStory.title,
        content: generatedStory.content,
        moral: generatedStory.moral,
        wordCount: generatedStory.wordCount,
        ageGroup: validatedData.age,
        storyType: validatedData.type,
      });

      res.json(savedStory);
    } catch (error) {
      console.error("Story generation error:", error);
      
      if (error instanceof Error) {
        // If it's a content moderation error, return specific message
        if (error.message.includes("keep the magic safe")) {
          res.status(400).json({ 
            error: "inappropriate_content",
            message: error.message 
          });
          return;
        }
      }
      
      res.status(500).json({ 
        error: "generation_failed",
        message: error instanceof Error ? error.message : "The story fairies are taking a break! Please try again in a moment." 
      });
    }
  });

  // Get story by ID
  app.get("/api/stories/:id", async (req, res) => {
    try {
      const story = await storage.getStory(req.params.id);
      if (!story) {
        res.status(404).json({ error: "Story not found" });
        return;
      }
      res.json(story);
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve story" });
    }
  });

  // Get recent stories
  app.get("/api/stories", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const stories = await storage.getRecentStories(limit);
      res.json(stories);
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve stories" });
    }
  });

  // Generate speech from story text
  app.post("/api/tts/generate", async (req, res) => {
    try {
      const { text } = req.body;
      
      if (!text || typeof text !== 'string') {
        res.status(400).json({ error: "Text is required" });
        return;
      }

      // Limit text length to prevent abuse (ElevenLabs has character limits)
      if (text.length > 5000) {
        res.status(400).json({ error: "Text too long. Maximum 5000 characters." });
        return;
      }

      const audioBuffer = await generateSpeech(text);
      
      res.set({
        'Content-Type': 'audio/mpeg',
        'Content-Length': audioBuffer.length,
        'Cache-Control': 'public, max-age=3600', // Cache for 1 hour
      });
      
      res.send(audioBuffer);
    } catch (error) {
      console.error("TTS generation error:", error);
      res.status(500).json({ 
        error: "tts_failed",
        message: error instanceof Error ? error.message : "Failed to generate speech. Please try again." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
