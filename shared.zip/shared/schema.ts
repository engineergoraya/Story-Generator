import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const stories = pgTable("stories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  moral: text("moral").notNull(),
  wordCount: integer("word_count").notNull(),
  ageGroup: text("age_group").notNull(),
  storyType: text("story_type").notNull(), // 'custom' or 'surprise'
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertStorySchema = createInsertSchema(stories).omit({
  id: true,
  createdAt: true,
});

export const storyGenerationSchema = z.object({
  type: z.enum(['custom', 'surprise']),
  age: z.string(),
  storyIdea: z.string().optional(),
  favoriteCreature: z.string().optional(),
  setting: z.string().optional(),
  mood: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertStory = z.infer<typeof insertStorySchema>;
export type Story = typeof stories.$inferSelect;
export type StoryGenerationRequest = z.infer<typeof storyGenerationSchema>;
